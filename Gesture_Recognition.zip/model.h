#pragma once
#include <stdarg.h>
#include <stdlib.h>
#include <stdint.h>
namespace Eloquent {
    namespace ML {
        namespace Port {
            class RandomForest {
                public:
                    /**
                    * Predict class for features vector
                    */
                    int predict(float *x) {
                        uint8_t votes[3] = { 0 };
                        // tree #1
                        if (x[2] <= 0.7140600681304932) {
                            if (x[1] <= 0.513569563627243) {
                                if (x[1] <= 0.48751427233219147) {
                                    votes[1] += 1;
                                }

                                else {
                                    if (x[1] <= 0.5009905099868774) {
                                        votes[0] += 1;
                                    }

                                    else {
                                        votes[1] += 1;
                                    }
                                }
                            }

                            else {
                                votes[0] += 1;
                            }
                        }

                        else {
                            votes[2] += 1;
                        }

                        // tree #2
                        if (x[2] <= 0.7185328602790833) {
                            if (x[0] <= -0.2499500885605812) {
                                votes[1] += 1;
                            }

                            else {
                                votes[0] += 1;
                            }
                        }

                        else {
                            votes[2] += 1;
                        }

                        // tree #3
                        if (x[1] <= 0.5186396241188049) {
                            if (x[1] <= 0.27140267193317413) {
                                votes[2] += 1;
                            }

                            else {
                                if (x[1] <= 0.490337535738945) {
                                    votes[1] += 1;
                                }

                                else {
                                    if (x[2] <= 0.3565540239214897) {
                                        votes[1] += 1;
                                    }

                                    else {
                                        votes[0] += 1;
                                    }
                                }
                            }
                        }

                        else {
                            votes[0] += 1;
                        }

                        // tree #4
                        if (x[0] <= -0.25075002759695053) {
                            votes[1] += 1;
                        }

                        else {
                            if (x[1] <= 0.3440476730465889) {
                                votes[2] += 1;
                            }

                            else {
                                votes[0] += 1;
                            }
                        }

                        // tree #5
                        if (x[1] <= 0.23765089362859726) {
                            votes[2] += 1;
                        }

                        else {
                            if (x[1] <= 0.513569563627243) {
                                if (x[0] <= -0.22067293524742126) {
                                    votes[1] += 1;
                                }

                                else {
                                    votes[0] += 1;
                                }
                            }

                            else {
                                votes[0] += 1;
                            }
                        }

                        // tree #6
                        if (x[0] <= -0.23874268680810928) {
                            votes[1] += 1;
                        }

                        else {
                            if (x[0] <= 0.3431716710329056) {
                                votes[0] += 1;
                            }

                            else {
                                votes[2] += 1;
                            }
                        }

                        // tree #7
                        if (x[0] <= 0.3431716710329056) {
                            if (x[0] <= -0.25075002759695053) {
                                votes[1] += 1;
                            }

                            else {
                                votes[0] += 1;
                            }
                        }

                        else {
                            votes[2] += 1;
                        }

                        // tree #8
                        if (x[0] <= -0.2382657825946808) {
                            votes[1] += 1;
                        }

                        else {
                            if (x[2] <= 0.721977561712265) {
                                votes[0] += 1;
                            }

                            else {
                                votes[2] += 1;
                            }
                        }

                        // tree #9
                        if (x[1] <= 0.2689739316701889) {
                            votes[2] += 1;
                        }

                        else {
                            if (x[0] <= -0.24042458087205887) {
                                votes[1] += 1;
                            }

                            else {
                                votes[0] += 1;
                            }
                        }

                        // tree #10
                        if (x[2] <= 0.7140600681304932) {
                            if (x[0] <= -0.25523024052381516) {
                                votes[1] += 1;
                            }

                            else {
                                votes[0] += 1;
                            }
                        }

                        else {
                            votes[2] += 1;
                        }

                        // tree #11
                        if (x[1] <= 0.513569563627243) {
                            if (x[0] <= -0.23559009283781052) {
                                votes[1] += 1;
                            }

                            else {
                                if (x[0] <= 0.29434625059366226) {
                                    votes[0] += 1;
                                }

                                else {
                                    votes[2] += 1;
                                }
                            }
                        }

                        else {
                            votes[0] += 1;
                        }

                        // tree #12
                        if (x[2] <= 0.721977561712265) {
                            if (x[1] <= 0.5199854075908661) {
                                if (x[2] <= 0.43084578216075897) {
                                    votes[1] += 1;
                                }

                                else {
                                    votes[0] += 1;
                                }
                            }

                            else {
                                votes[0] += 1;
                            }
                        }

                        else {
                            votes[2] += 1;
                        }

                        // return argmax of votes
                        uint8_t classIdx = 0;
                        float maxVotes = votes[0];

                        for (uint8_t i = 1; i < 3; i++) {
                            if (votes[i] > maxVotes) {
                                classIdx = i;
                                maxVotes = votes[i];
                            }
                        }

                        return classIdx;
                    }
                };
const char* idx_to_label(int index) {   // 2️⃣ opens here
switch(index) {
  case 0: return "wave";
  case 1: return "flick";
  case 2: return "circle";
  default: return "unknown";
  }
            }
        }
    }
}